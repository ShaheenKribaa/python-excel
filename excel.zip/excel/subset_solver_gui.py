import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import openpyxl
from itertools import combinations
import os

class SubsetSolverGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Subset Sum Solver - Excel Interface")
        self.root.geometry("600x500")
        self.root.configure(bg='#f0f0f0')
        
        # Variables
        self.file_path = tk.StringVar()
        self.numbers_start = tk.StringVar(value="A1")
        self.numbers_end = tk.StringVar(value="A10")
        self.targets_start = tk.StringVar(value="B1")
        self.targets_end = tk.StringVar(value="B10")
        self.output_column = tk.StringVar(value="C")
        
        self.setup_ui()
        
    def setup_ui(self):
        # Main frame
        main_frame = ttk.Frame(self.root, padding="20")
        main_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # Configure grid weights
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(0, weight=1)
        main_frame.columnconfigure(1, weight=1)
        
        # Title
        title_label = ttk.Label(main_frame, text="Subset Sum Solver", 
                               font=('Arial', 16, 'bold'))
        title_label.grid(row=0, column=0, columnspan=3, pady=(0, 20))
        
        # File selection section
        file_frame = ttk.LabelFrame(main_frame, text="Excel File Selection", padding="10")
        file_frame.grid(row=1, column=0, columnspan=3, sticky=(tk.W, tk.E), pady=(0, 15))
        file_frame.columnconfigure(1, weight=1)
        
        ttk.Label(file_frame, text="Excel File:").grid(row=0, column=0, sticky=tk.W, padx=(0, 10))
        ttk.Entry(file_frame, textvariable=self.file_path, width=50).grid(row=0, column=1, sticky=(tk.W, tk.E), padx=(0, 10))
        ttk.Button(file_frame, text="Browse", command=self.browse_file).grid(row=0, column=2)
        
        # Range selection section
        range_frame = ttk.LabelFrame(main_frame, text="Range Configuration", padding="10")
        range_frame.grid(row=2, column=0, columnspan=3, sticky=(tk.W, tk.E), pady=(0, 15))
        range_frame.columnconfigure(1, weight=1)
        range_frame.columnconfigure(3, weight=1)
        
        # Numbers range
        ttk.Label(range_frame, text="Numbers Range:").grid(row=0, column=0, sticky=tk.W, padx=(0, 10))
        ttk.Entry(range_frame, textvariable=self.numbers_start, width=10).grid(row=0, column=1, sticky=tk.W, padx=(0, 5))
        ttk.Label(range_frame, text="to").grid(row=0, column=2, padx=5)
        ttk.Entry(range_frame, textvariable=self.numbers_end, width=10).grid(row=0, column=3, sticky=tk.W, padx=(5, 0))
        
        # Targets range
        ttk.Label(range_frame, text="Targets Range:").grid(row=1, column=0, sticky=tk.W, padx=(0, 10), pady=(10, 0))
        ttk.Entry(range_frame, textvariable=self.targets_start, width=10).grid(row=1, column=1, sticky=tk.W, padx=(0, 5), pady=(10, 0))
        ttk.Label(range_frame, text="to").grid(row=1, column=2, padx=5, pady=(10, 0))
        ttk.Entry(range_frame, textvariable=self.targets_end, width=10).grid(row=1, column=3, sticky=tk.W, padx=(5, 0), pady=(10, 0))
        
        # Output column
        ttk.Label(range_frame, text="Output Column:").grid(row=2, column=0, sticky=tk.W, padx=(0, 10), pady=(10, 0))
        ttk.Entry(range_frame, textvariable=self.output_column, width=10).grid(row=2, column=1, sticky=tk.W, padx=(0, 5), pady=(10, 0))
        
        # Preview section
        preview_frame = ttk.LabelFrame(main_frame, text="Data Preview", padding="10")
        preview_frame.grid(row=3, column=0, columnspan=3, sticky=(tk.W, tk.E, tk.N, tk.S), pady=(0, 15))
        preview_frame.columnconfigure(0, weight=1)
        preview_frame.rowconfigure(0, weight=1)
        
        # Create treeview for preview
        self.preview_tree = ttk.Treeview(preview_frame, columns=('Numbers', 'Targets'), show='headings', height=8)
        self.preview_tree.heading('Numbers', text='Numbers')
        self.preview_tree.heading('Targets', text='Targets')
        self.preview_tree.column('Numbers', width=200)
        self.preview_tree.column('Targets', width=200)
        self.preview_tree.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # Scrollbar for preview
        preview_scrollbar = ttk.Scrollbar(preview_frame, orient=tk.VERTICAL, command=self.preview_tree.yview)
        preview_scrollbar.grid(row=0, column=1, sticky=(tk.N, tk.S))
        self.preview_tree.configure(yscrollcommand=preview_scrollbar.set)
        
        # Buttons frame
        button_frame = ttk.Frame(main_frame)
        button_frame.grid(row=4, column=0, columnspan=3, pady=(0, 10))
        
        ttk.Button(button_frame, text="Load Preview", command=self.load_preview).pack(side=tk.LEFT, padx=(0, 10))
        ttk.Button(button_frame, text="Run Solver", command=self.run_solver).pack(side=tk.LEFT, padx=(0, 10))
        ttk.Button(button_frame, text="Clear", command=self.clear_preview).pack(side=tk.LEFT)
        
        # Status bar
        self.status_var = tk.StringVar(value="Ready")
        status_bar = ttk.Label(main_frame, textvariable=self.status_var, relief=tk.SUNKEN, anchor=tk.W)
        status_bar.grid(row=5, column=0, columnspan=3, sticky=(tk.W, tk.E), pady=(10, 0))
        
    def browse_file(self):
        filename = filedialog.askopenfilename(
            title="Select Excel File",
            filetypes=[("Excel files", "*.xlsx *.xls"), ("All files", "*.*")]
        )
        if filename:
            self.file_path.set(filename)
            self.status_var.set(f"File selected: {os.path.basename(filename)}")
            
    def parse_range(self, range_str):
        """Parse Excel range like 'A1' to (column, row)"""
        if not range_str:
            return None, None
            
        # Extract column and row
        col = ""
        row = ""
        for char in range_str:
            if char.isalpha():
                col += char.upper()
            else:
                row += char
                
        try:
            return col, int(row)
        except ValueError:
            return None, None
            
    def load_preview(self):
        if not self.file_path.get():
            messagebox.showerror("Error", "Please select an Excel file first.")
            return
            
        try:
            # Clear existing items
            self.clear_preview()
            
            # Load workbook
            wb = openpyxl.load_workbook(self.file_path.get())
            ws = wb.active
            
            # Parse ranges
            num_col, num_start = self.parse_range(self.numbers_start.get())
            _, num_end = self.parse_range(self.numbers_end.get())
            target_col, target_start = self.parse_range(self.targets_start.get())
            _, target_end = self.parse_range(self.targets_end.get())
            
            if not all([num_col, num_start, num_end, target_col, target_start, target_end]):
                messagebox.showerror("Error", "Invalid range format. Use format like 'A1', 'B10', etc.")
                return
                
            # Load data
            numbers = []
            targets = []
            
            for i in range(num_start, num_end + 1):
                cell_value = ws[f"{num_col}{i}"].value
                numbers.append(cell_value if cell_value is not None else 0)
                
            for i in range(target_start, target_end + 1):
                cell_value = ws[f"{target_col}{i}"].value
                targets.append(cell_value if cell_value is not None else 0)
                
            # Display in preview
            max_rows = max(len(numbers), len(targets))
            for i in range(max_rows):
                num_val = numbers[i] if i < len(numbers) else ""
                target_val = targets[i] if i < len(targets) else ""
                self.preview_tree.insert('', 'end', values=(num_val, target_val))
                
            self.status_var.set(f"Preview loaded: {len(numbers)} numbers, {len(targets)} targets")
            
        except Exception as e:
            messagebox.showerror("Error", f"Failed to load preview: {str(e)}")
            self.status_var.set("Error loading preview")
            
    def clear_preview(self):
        for item in self.preview_tree.get_children():
            self.preview_tree.delete(item)
        self.status_var.set("Preview cleared")
        
    def find_combinations(self, numbers, target):
        """Find all index combinations that sum to target"""
        results = []
        n = len(numbers)
        for r in range(1, n+1):
            for combo in combinations(range(n), r):
                if sum(numbers[i] for i in combo) == target:
                    results.append(combo)
        return results
        
    def run_solver(self):
        if not self.file_path.get():
            messagebox.showerror("Error", "Please select an Excel file first.")
            return
            
        try:
            # Load workbook
            wb = openpyxl.load_workbook(self.file_path.get())
            ws = wb.active
            
            # Parse ranges
            num_col, num_start = self.parse_range(self.numbers_start.get())
            _, num_end = self.parse_range(self.numbers_end.get())
            target_col, target_start = self.parse_range(self.targets_start.get())
            _, target_end = self.parse_range(self.targets_end.get())
            output_col = self.output_column.get().upper()
            
            if not all([num_col, num_start, num_end, target_col, target_start, target_end]):
                messagebox.showerror("Error", "Invalid range format.")
                return
                
            # Load data
            numbers = []
            for i in range(num_start, num_end + 1):
                cell_value = ws[f"{num_col}{i}"].value
                numbers.append(cell_value if cell_value is not None else 0)
                
            targets = []
            for i in range(target_start, target_end + 1):
                cell_value = ws[f"{target_col}{i}"].value
                targets.append(cell_value if cell_value is not None else 0)
                
            # Process each target
            results_count = 0
            for i, target in enumerate(targets):
                combos = self.find_combinations(numbers, target)
                output_row = target_start + i
                
                if combos:
                    results_str = []
                    for combo in combos:
                        cells_used = "+".join([f"{num_col}{num_start + idx}" for idx in combo])
                        results_str.append(f"({cells_used})")
                    ws[f"{output_col}{output_row}"] = ", ".join(results_str)
                    results_count += 1
                else:
                    ws[f"{output_col}{output_row}"] = "No combination"
                    
            # Save file
            wb.save(self.file_path.get())
            
            messagebox.showinfo("Success", 
                              f"Processing complete!\n"
                              f"Results written to column {output_col}\n"
                              f"Found combinations for {results_count} targets")
            self.status_var.set(f"Completed: {results_count} results found")
            
        except Exception as e:
            messagebox.showerror("Error", f"Failed to run solver: {str(e)}")
            self.status_var.set("Error running solver")

def main():
    root = tk.Tk()
    app = SubsetSolverGUI(root)
    root.mainloop()

if __name__ == "__main__":
    main()
