import openpyxl
from itertools import combinations

def find_combinations(numbers, target):
    """Find all index combinations that sum to target"""
    results = []
    n = len(numbers)
    for r in range(1, n+1):
        for combo in combinations(range(n), r):
            if sum(numbers[i] for i in combo) == target:
                results.append(combo)
    return results

# === Load Excel file ===
file_path = "classeur1.xlsx"   # <-- Change this to your Excel filename
wb = openpyxl.load_workbook(file_path)
ws = wb.active

# === Read data from Excel ===
# A1:A10 = numbers list
numbers = [ws[f"A{i}"].value for i in range(1, 11)]

# B1:B10 = target values
targets = [ws[f"B{i}"].value for i in range(1, 11)]

# === Process each target and write results in C column ===
for row, target in enumerate(targets, start=1):
    combos = find_combinations(numbers, target)
    if combos:
        results_str = []
        for combo in combos:
            cells_used = "+".join([f"A{i+1}" for i in combo])  # Excel-style references
            results_str.append(f"({cells_used})")
        ws[f"C{row}"] = ", ".join(results_str)
    else:
        ws[f"C{row}"] = "No combination"

# === Save back to same file ===
wb.save(file_path)

print("✅ Done! Results written to column C in the same Excel file.")
